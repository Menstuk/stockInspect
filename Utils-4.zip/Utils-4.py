def prepare_for_prediction(df, num_of_days_before):
    
    new_df = pd.DataFrame(columns=['id', 'close_price'] + ['close_price_{}_days_ago'.format(i) for i in range(1, num_of_days_before + 1)])

    for id_value in df['id'].unique():
        id_df = df[df['id'] == id_value]
        close_prices = id_df['close_price'].tail(num_of_days_before + 1).values
    
        new_row = {'id': id_value, 'close_price': close_prices[-1]}
        for i in range(1, num_of_days_before + 1):
            new_row['close_price_{}_days_ago'.format(i)] = close_prices[-(i+1)]
    
        new_df = new_df.append(new_row, ignore_index=True)

    return new_df